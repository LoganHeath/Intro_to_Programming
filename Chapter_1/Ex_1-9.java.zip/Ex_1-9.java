/*
Author: Logan Heath
Date: 9/25/18

Compute expression
*/

class Ex_1_9 {
	public static void main(String[] args) {
	System.out.println(4.5*7.9);
	}
}